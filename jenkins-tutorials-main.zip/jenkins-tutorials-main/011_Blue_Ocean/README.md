# Blue ocean

Blue ocean is 100% free & open source application that gives a new experience on Jenknis pipelines. Installation of blue ocean is very easy.

1. Click Manage Jenkins in the sidebar then Manage Plugins.
2. Choose the Available tab and use the search bar to find Blue Ocean.
3. Click the checkbox in the Install column.
4. Click either Install without restart or Download now and install after restart.

![Blue Ocean](/images/journey.png)

<p align="center">
<a href="https://www.youtube.com/c/xtremeexcel?sub_confirmation=1"><img src="/images/subscribe.gif" width="25%" height="25%"></a>
</p>
