### What is Devops and Why it is important?

Devops is a culture, philosophy, set of practices or processes followed with the help of special tools. It aims to enhance or streamline organization's ability to deliver applications.

![Devops](/images/devops.png)

<p align="center">
<a href="https://www.youtube.com/c/xtremeexcel?sub_confirmation=1"><img src="/images/subscribe.gif" width="30%" height="30%"></a>
</p>
